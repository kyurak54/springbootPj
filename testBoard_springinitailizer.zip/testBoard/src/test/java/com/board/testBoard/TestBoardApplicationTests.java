package com.board.testBoard;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestBoardApplicationTests {

	@Test
	void contextLoads() {
	}

}
